package com.dam.baloncesto;

import com.dam.baloncesto.ejercicios.Ejercicio5;
import com.dam.baloncesto.ejercicios.Ejercicio6;
import com.dam.baloncesto.ejercicios.Ejercicio7;
import com.dam.baloncesto.util.HibernateUtil;
import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;
        
        if (!verificarConexion()) {
            System.err.println("\n❌ No se pudo conectar a la base de datos");
            return;
        }
        
        System.out.println("✅ Conexión a base de datos OK\n");
        
        while (!salir) {
            mostrarMenu();
            
            System.out.print("Selecciona una opción: ");
            String opcion = scanner.nextLine().trim();
            System.out.println();
            
            switch (opcion) {
                case "1":
                    ejecutarEjercicio5(scanner);
                    break;
                case "2":
                    ejecutarEjercicio6();
                    break;
                case "3":
                    probarConexion();
                    break;
                case "4":
                    mostrarAyuda();
                    break;
                case "7":
                    ejecutarEjercicio7(scanner);
                    break;
                case "0":
                    salir = true;
                    System.out.println("¡Hasta pronto!");
                    break;
                default:
                    System.out.println("❌ Opción inválida");
            }
            
            if (!salir) {
                System.out.println("\nPresiona Enter para continuar...");
                scanner.nextLine();
            }
        }
        
        scanner.close();
        HibernateUtil.shutdown();
    }
    
    private static void mostrarMenu() {
        System.out.println("\n╔════════════════════════════════════════════╗");
        System.out.println("║  SISTEMA DE BALONCESTO - HIBERNATE ORM    ║");
        System.out.println("╚════════════════════════════════════════════╝");
        System.out.println();
        System.out.println("  1. Ejercicio 5 - Estadísticas de un jugador");
        System.out.println("  2. Ejercicio 6 - Listado equipos y jugadores");
        System.out.println("  3. Probar conexión a base de datos");
        System.out.println("  4. Ayuda");
        System.out.println("  7. Ejercicio 7 - Ranking de jugadores por temporada");
        System.out.println("  0. Salir\n");
    }
    
    private static void ejecutarEjercicio5(Scanner scanner) {
        System.out.println("╔════════════════════════════════════════════╗");
        System.out.println("║  EJERCICIO 5: Estadísticas de Jugador     ║");
        System.out.println("╚════════════════════════════════════════════╝\n");
        
        System.out.println("Jugadores de ejemplo:");
        System.out.println("  227 - Kirk Hinrich (Bulls)");
        System.out.println("  300 - Kobe Bryant (Lakers)");
        System.out.println("  400 - Dwyane Wade (Heat)");
        System.out.println("  500 - Tim Duncan (Spurs)\n");
        
        System.out.print("Introduce el código del jugador: ");
        String codigoStr = scanner.nextLine().trim();
        
        String[] argumentos = {codigoStr};
        Ejercicio5.main(argumentos);
    }
    
    private static void ejecutarEjercicio6() {
        System.out.println("╔════════════════════════════════════════════╗");
        System.out.println("║  EJERCICIO 6: Listado de Equipos          ║");
        System.out.println("╚════════════════════════════════════════════╝\n");
        Ejercicio6.main(new String[0]);
    }
    
    private static void ejecutarEjercicio7(Scanner scanner) {
        // Llamada al Ejercicio7 corregido que pide la temporada y muestra ranking Top 10
        Ejercicio7.main(new String[0]);
    }
    
    private static void probarConexion() {
        System.out.println("╔════════════════════════════════════════════╗");
        System.out.println("║  PRUEBA DE CONEXIÓN                        ║");
        System.out.println("╚════════════════════════════════════════════╝\n");
        
        if (verificarConexion()) {
            System.out.println("✅ Conexión exitosa a la base de datos");
            System.out.println("Driver: MariaDB | URL: jdbc:mariadb://localhost:3306/baloncesto | Usuario: root");
        } else {
            System.out.println("❌ No se pudo conectar a la base de datos");
        }
    }
    
    private static boolean verificarConexion() {
        try {
            HibernateUtil.getSessionFactory().openSession().close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    private static void mostrarAyuda() {
        System.out.println("╔════════════════════════════════════════════╗");
        System.out.println("║  AYUDA                                     ║");
        System.out.println("╚════════════════════════════════════════════╝\n");
        System.out.println("Opciones:");
        System.out.println("1 - Muestra estadísticas de un jugador por código");
        System.out.println("2 - Lista equipos con jugadores y media de puntos");
        System.out.println("7 - Ranking de jugadores por temporada (Top 10)");
        System.out.println("0 - Salir del programa");
    }
}
