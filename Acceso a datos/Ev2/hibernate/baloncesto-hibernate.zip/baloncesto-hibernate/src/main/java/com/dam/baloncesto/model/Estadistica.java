/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dam.baloncesto.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

public class Estadistica implements Serializable {
    
    // Clave compuesta
    private String temporada;
    private Jugador jugador;
    
    // Estadísticas
    private BigDecimal puntosPorPartido;
    private BigDecimal asistenciasPorPartido;
    private BigDecimal taponesPorPartido;
    private BigDecimal rebotesPorPartido;
    
    // Constructores
    public Estadistica() {}
    
    public Estadistica(String temporada, Jugador jugador) {
        this.temporada = temporada;
        this.jugador = jugador;
    }
    
    // Getters y Setters
    public String getTemporada() {
        return temporada;
    }
    
    public void setTemporada(String temporada) {
        this.temporada = temporada;
    }
    
    public Jugador getJugador() {
        return jugador;
    }
    
    public void setJugador(Jugador jugador) {
        this.jugador = jugador;
    }
    
    public BigDecimal getPuntosPorPartido() {
        return puntosPorPartido;
    }
    
    public void setPuntosPorPartido(BigDecimal puntosPorPartido) {
        this.puntosPorPartido = puntosPorPartido;
    }
    
    public BigDecimal getAsistenciasPorPartido() {
        return asistenciasPorPartido;
    }
    
    public void setAsistenciasPorPartido(BigDecimal asistenciasPorPartido) {
        this.asistenciasPorPartido = asistenciasPorPartido;
    }
    
    public BigDecimal getTaponesPorPartido() {
        return taponesPorPartido;
    }
    
    public void setTaponesPorPartido(BigDecimal taponesPorPartido) {
        this.taponesPorPartido = taponesPorPartido;
    }
    
    public BigDecimal getRebotesPorPartido() {
        return rebotesPorPartido;
    }
    
    public void setRebotesPorPartido(BigDecimal rebotesPorPartido) {
        this.rebotesPorPartido = rebotesPorPartido;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Estadistica that = (Estadistica) o;
        return Objects.equals(temporada, that.temporada) &&
               Objects.equals(jugador, that.jugador);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(temporada, jugador);
    }
    
    @Override
    public String toString() {
        return "Estadistica{temporada='" + temporada + "', puntos=" + puntosPorPartido + "}";
    }
}