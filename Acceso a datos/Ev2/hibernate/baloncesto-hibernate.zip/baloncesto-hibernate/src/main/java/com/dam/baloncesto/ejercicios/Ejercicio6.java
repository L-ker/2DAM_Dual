/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dam.baloncesto.ejercicios;

import com.dam.baloncesto.model.Equipo;
import com.dam.baloncesto.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.math.BigDecimal;
import java.util.List;

public class Ejercicio6 {
    
    public static void main(String[] args) {
        
        Session session = null;
        Transaction tx = null;
        
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            
            // Contar equipos
            String hqlCount = "SELECT COUNT(e) FROM Equipo e";
            Long totalEquipos = session.createQuery(hqlCount, Long.class)
                    .uniqueResult();
            
            System.out.println("\nNúmero de Equipos: " + totalEquipos);
            
            // Obtener equipos ordenados
            String hqlEquipos = "FROM Equipo e ORDER BY e.nombre";
            List<Equipo> equipos = session.createQuery(hqlEquipos, Equipo.class)
                    .list();
            
            // Listar jugadores por equipo
            for (Equipo equipo : equipos) {
                System.out.println("===================================================");
                System.out.println("Equipo: " + equipo.getNombre());
                
                // Consulta con media de puntos
                String hqlJugadores = 
                    "SELECT j.codigo, j.nombre, AVG(e.puntosPorPartido) " +
                    "FROM Jugador j " +
                    "LEFT JOIN j.estadisticas e " +
                    "WHERE j.equipo.nombre = :nombreEquipo " +
                    "GROUP BY j.codigo, j.nombre " +
                    "ORDER BY j.nombre";
                
                List<Object[]> jugadores = session.createQuery(hqlJugadores, Object[].class)
                        .setParameter("nombreEquipo", equipo.getNombre())
                        .list();
                
                if (jugadores.isEmpty()) {
                    System.out.println("  (Sin jugadores registrados)");
                } else {
                    for (Object[] row : jugadores) {
                        Integer codigo = (Integer) row[0];
                        String nombre = (String) row[1];
                        BigDecimal media = (BigDecimal) row[2];
                        
                        String mediaStr = (media != null) 
                            ? String.format("%.2f", media) 
                            : "N/A";
                        
                        System.out.printf("  %d, %s: %s%n", codigo, nombre, mediaStr);
                    }
                }
            }
            
            System.out.println("===================================================\n");
            
            tx.commit();
            
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            if (session != null) session.close();
        }
    }
}