/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dam.baloncesto.model;

import java.util.HashSet;
import java.util.Set;

public class Jugador {
    
    private Integer codigo;
    private String nombre;
    private String procedencia;
    private String altura;
    private Integer peso;
    private String posicion;
    private Equipo equipo;
    private Set<Estadistica> estadisticas = new HashSet<>();
    
    // Constructores
    public Jugador() {}
    
    public Jugador(Integer codigo, String nombre, String procedencia, 
                   String altura, Integer peso, String posicion) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.procedencia = procedencia;
        this.altura = altura;
        this.peso = peso;
        this.posicion = posicion;
    }
    
    // Getters y Setters
    public Integer getCodigo() {
        return codigo;
    }
    
    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getProcedencia() {
        return procedencia;
    }
    
    public void setProcedencia(String procedencia) {
        this.procedencia = procedencia;
    }
    
    public String getAltura() {
        return altura;
    }
    
    public void setAltura(String altura) {
        this.altura = altura;
    }
    
    public Integer getPeso() {
        return peso;
    }
    
    public void setPeso(Integer peso) {
        this.peso = peso;
    }
    
    public String getPosicion() {
        return posicion;
    }
    
    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }
    
    public Equipo getEquipo() {
        return equipo;
    }
    
    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }
    
    public Set<Estadistica> getEstadisticas() {
        return estadisticas;
    }
    
    public void setEstadisticas(Set<Estadistica> estadisticas) {
        this.estadisticas = estadisticas;
    }
    
    @Override
    public String toString() {
        return "Jugador{codigo=" + codigo + ", nombre='" + nombre + "'}";
    }
}
