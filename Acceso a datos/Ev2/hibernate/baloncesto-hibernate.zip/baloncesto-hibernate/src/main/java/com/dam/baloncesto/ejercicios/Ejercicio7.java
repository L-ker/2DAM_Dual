package com.dam.baloncesto.ejercicios;

import com.dam.baloncesto.model.Estadistica;
import com.dam.baloncesto.util.HibernateUtil;
import java.math.BigDecimal;
import java.util.List;
import java.util.Scanner;
import org.hibernate.Session;

public class Ejercicio7 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("??????????????????????????????????????????????");
        System.out.println("?  EJERCICIO 7: Ranking de Jugadores        ?");
        System.out.println("??????????????????????????????????????????????\n");

        System.out.print("Introduce la temporada (ej: 07/08): ");
        String temporada = scanner.nextLine().trim();

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            List<Object[]> resultados = session.createQuery(
                    "SELECT e.jugador.nombre, e.jugador.equipo.nombre, " +
                    "e.puntosPorPartido, e.asistenciasPorPartido, e.rebotesPorPartido, e.taponesPorPartido " +
                    "FROM Estadistica e " +
                    "WHERE e.temporada = :temporada " +
                    "ORDER BY e.puntosPorPartido DESC", Object[].class)
                .setParameter("temporada", temporada)
                .setMaxResults(10)
                .list();

            if (resultados.isEmpty()) {
                System.out.println("❌ No se encontraron estadísticas para la temporada " + temporada);
                return;
            }

            System.out.println("\nRanking Top 10 jugadores - Temporada " + temporada + ":");
            System.out.println("-------------------------------------------------------------");
            System.out.printf("%-20s %-15s %-6s %-6s %-6s %-6s%n", "Jugador", "Equipo", "Ptos", "Asis", "Reb", "Tap");
            System.out.println("-------------------------------------------------------------");

            for (Object[] fila : resultados) {
                String nombre = (String) fila[0];
                String equipo = (String) fila[1];

                // Convertir BigDecimal a double
                double pts = ((BigDecimal) fila[2]).doubleValue();
                double asis = ((BigDecimal) fila[3]).doubleValue();
                double reb = ((BigDecimal) fila[4]).doubleValue();
                double tap = ((BigDecimal) fila[5]).doubleValue();

                System.out.printf("%-20s %-15s %-6.1f %-6.1f %-6.1f %-6.1f%n", nombre, equipo, pts, asis, reb, tap);
            }

        } catch (Exception e) {
            System.out.println("? Error al consultar la base de datos: " + e.getMessage());
        }
    }
}
