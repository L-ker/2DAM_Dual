/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dam.baloncesto.ejercicios;

import com.dam.baloncesto.model.Estadistica;
import com.dam.baloncesto.model.Jugador;
import com.dam.baloncesto.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

/**
 * EJERCICIO 5: Mostrar estadísticas de un jugador
 * 
 * Entrada: código de jugador como argumento del programa
 * Salida: Datos del jugador y sus estadísticas por temporada
 * 
 * ESTRUCTURA DEL CÓDIGO:
 * ⚙️ Java puro: validaciones, lógica de negocio, main()
 * 🔷 Hibernate ORM: Session, load(), consultas HQL
 */
public class Ejercicio5 {
    
    public static void main(String[] args) {
        
        // ===== VALIDACIÓN DE ENTRADA (⚙️ JAVA PURO) =====
        
        // Comprobar que se ha pasado un argumento
        if (args.length == 0) {
            System.err.println("❌ Error: Debes proporcionar el código del jugador");
            System.out.println("Uso: java Ejercicio5_EstadisticasJugador <codigo>");
            System.exit(1);
        }
        
        // Validar que el argumento es numérico
        int codigoJugador;
        try {
            codigoJugador = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            System.err.println("❌ Error: El código debe ser numérico");
            System.exit(1);
            return;
        }
        
        // ===== TRABAJO CON HIBERNATE (🔷 ORM) =====
        
        Session session = null;
        Transaction tx = null;
        
        try {
            // 🔷 HIBERNATE: Abrir sesión (conexión a BD)
            session = HibernateUtil.getSessionFactory().openSession();
            
            // 🔷 HIBERNATE: Iniciar transacción
            tx = session.beginTransaction();
            
            // 🔷 HIBERNATE: Cargar jugador por su ID (PRIMARY KEY)
            // El método get() devuelve null si no existe
            Jugador jugador = session.get(Jugador.class, codigoJugador);
            
            // ⚙️ JAVA: Validar si existe el jugador
            if (jugador == null) {
                System.out.println("❌ No existe ningún jugador con código: " + codigoJugador);
                tx.rollback();
                return;
            }
            
            // ===== MOSTRAR DATOS DEL JUGADOR (⚙️ JAVA PURO) =====
            
            System.out.println("\n╔════════════════════════════════════════════╗");
            System.out.println("║  DATOS DEL JUGADOR: " + codigoJugador);
            System.out.println("╚════════════════════════════════════════════╝");
            System.out.println("Nombre : " + jugador.getNombre());
            System.out.println("Equipo : " + 
                (jugador.getEquipo() != null ? jugador.getEquipo().getNombre() : "Sin equipo"));
            
            // ===== CONSULTA HQL PARA ESTADÍSTICAS (🔷 HIBERNATE) =====
            
            // 🔷 HIBERNATE: Consulta HQL (no SQL!)
            // HQL trabaja con OBJETOS y ATRIBUTOS, no con tablas y columnas
            String hql = "FROM Estadistica e WHERE e.jugador.codigo = :codigo ORDER BY e.temporada";
            
            // 🔷 HIBERNATE: Crear query con parámetros nombrados
            List<Estadistica> estadisticas = session.createQuery(hql, Estadistica.class)
                    .setParameter("codigo", codigoJugador)
                    .list();
            
            // ⚙️ JAVA: Validar si tiene estadísticas
            if (estadisticas.isEmpty()) {
                System.out.println("\n⚠️ Este jugador no tiene estadísticas registradas");
            } else {
                // ⚙️ JAVA: Mostrar tabla de estadísticas
                mostrarEstadisticas(estadisticas);
            }
            
            // 🔷 HIBERNATE: Confirmar transacción
            tx.commit();
            
        } catch (Exception e) {
            // En caso de error, deshacer cambios
            if (tx != null) {
                tx.rollback();
            }
            System.err.println("❌ Error al consultar la base de datos:");
            e.printStackTrace();
            
        } finally {
            // 🔷 HIBERNATE: Cerrar sesión siempre
            if (session != null) {
                session.close();
            }
        }
    }
    
    /**
     * Método auxiliar para mostrar estadísticas en formato tabla
     * ⚙️ JAVA PURO - Lógica de presentación
     */
    private static void mostrarEstadisticas(List<Estadistica> estadisticas) {
        System.out.println("\nTemporada  Ptos   Asis   Tap    Reb");
        System.out.println("==========================================");
        
        for (Estadistica est : estadisticas) {
            System.out.printf("%-10s %-6.1f %-6.1f %-6.1f %-6.1f%n",
                est.getTemporada(),
                est.getPuntosPorPartido(),
                est.getAsistenciasPorPartido(),
                est.getTaponesPorPartido(),
                est.getRebotesPorPartido()
            );
        }
        
        System.out.println("==========================================");
        System.out.println("Num de registros: " + estadisticas.size());
        System.out.println("==========================================\n");
    }
}

/*
 * 📚 RESUMEN PARA LOS ALUMNOS:
 * 
 * ¿QUÉ ES JAVA PURO? ⚙️
 * - Validaciones (if, try-catch)
 * - Lógica de negocio (cálculos, formatos)
 * - Métodos auxiliares (mostrarEstadisticas)
 * - main() y estructura del programa
 * 
 * ¿QUÉ ES HIBERNATE/ORM? 🔷
 * - Session: conexión a BD
 * - session.get(): cargar objeto por ID
 * - HQL: consultas orientadas a objetos
 * - Relaciones automáticas (jugador.getEquipo())
 * - Transacciones (tx.commit(), tx.rollback())
 * 
 * ¿QUÉ NOS AHORRA HIBERNATE?
 * - NO escribimos SQL manualmente
 * - NO usamos ResultSet ni PreparedStatement
 * - NO mapeamos filas a objetos manualmente
 * - Las RELACIONES se cargan automáticamente
 * 
 * COMPARA CON JDBC:
 * Con JDBC necesitarías:
 * 1. Escribir SQL: "SELECT * FROM jugadores WHERE codigo = ?"
 * 2. PreparedStatement con parámetros
 * 3. ResultSet para leer resultados
 * 4. Crear objeto Jugador manualmente
 * 5. Segunda consulta para estadísticas
 * 6. Mapear ResultSet a objetos Estadistica
 * 
 * Con Hibernate:
 * 1. session.get(Jugador.class, codigo) → ¡Ya está!
 * 2. Query HQL simple y legible
 * 3. Lista de objetos directamente
 */