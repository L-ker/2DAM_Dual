/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dam.baloncesto.model;



import java.util.HashSet;
import java.util.Set;

public class Equipo {
    
    private String nombre;
    private String ciudad;
    private String conferencia;
    private String division;
    private Set<Jugador> jugadores = new HashSet<>();
    
    // Constructores
    public Equipo() {}
    
    public Equipo(String nombre, String ciudad, String conferencia, String division) {
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.conferencia = conferencia;
        this.division = division;
    }
    
    // Getters y Setters
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getCiudad() {
        return ciudad;
    }
    
    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }
    
    public String getConferencia() {
        return conferencia;
    }
    
    public void setConferencia(String conferencia) {
        this.conferencia = conferencia;
    }
    
    public String getDivision() {
        return division;
    }
    
    public void setDivision(String division) {
        this.division = division;
    }
    
    public Set<Jugador> getJugadores() {
        return jugadores;
    }
    
    public void setJugadores(Set<Jugador> jugadores) {
        this.jugadores = jugadores;
    }
    
    @Override
    public String toString() {
        return "Equipo{nombre='" + nombre + "', ciudad='" + ciudad + "'}";
    }
}